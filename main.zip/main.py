import speech_recognition as sr
import pyttsx3
import pywhatkit
import datetime
import wikipedia
import pyjokes
import spotify
import webbrowser
import os


listener = sr.Recognizer()
engine = pyttsx3.init()
voices= engine.getProperty('voices')
engine.setProperty('voice', voices[1].id)


def talk(text):
    engine.say(text)
    engine.runAndWait()

def take_command():
    try:
        with sr.Microphone() as source:
            print('listenning...')
            voice = listener.listen(source)
            command = listener.recognize_google(voice)
            command = command.lower()
            if 'alexa' in command:
                command=command.replace('shashi', '')
                print(command)
    except:
        pass
    return command
def kids_mode():
    talk('Kids mode activated, Welcome to kids mode')
    command1=True
    while command1!='stop' or 'exit' or 'close' or 'normal':
        command=take_command()
        talk(command)

def run_shashi():
    command = take_command()
    print(command)
    if 'song' in command:
        talk('pleying song on youtube')
        song = command.replace('song', '')
        pywhatkit.playonyt(song)
    # elif 'spotify' in command:
    #     song = command.replace('play', '')
    #     talk('playing'+ song)
    #     pywhatkit.playon(song)
    elif 'time' in command:
        time = datetime.datetime.now().strftime('%I:%M %p')
        talk('Current time is'+time)
    elif 'who is' in command:
        person = command.replace('who is', '')
        info = wikipedia.summary(person,2)
        print(info)
        talk('according to wikipedia')
        talk(info)
           
    elif 'date' in command:
        talk('sorry, I cant go with you, i am a virtual assistance')
    elif 'are you single' in command:
        talk('I am in a relationship with Vijay')
    elif 'joke' in command:
        talk(pyjokes.get_joke())

    elif 'google' in command:
        talk('opening google')
        webbrowser.open('google.com')

    elif 'open youtube' in command:
        talk('opening youtube')
        webbrowser.open('youtube.com')

    elif 'open wikipedia' 'wikipedia' in command:
        talk('opening wikipedia')
        webbrowser.open('wikipedia.com')

    elif 'what is your name' or 'your name' in command:
        talk('My name is shashi, I am your virtual assistance')

    elif 'chat gpt' or 'chatgpt' or 'chat GPT' in command:
        talk('opening chat gpt')
        webbrowser.open('chat.openai.com')

    elif 'open code' in command:
        talk('Openning vs code')
        target1 = 'C:\\Users\\91916\\Desktop\\Visual Studio Code.lnk'
        os.startfile(target1)        

    elif 'stack overflow' in command:
        talk('opening stack overflow')
        webbrowser.open('stackoverflow.com')

    elif 'where are you from' in command:
        talk('I am from internet')

    elif 'chrome' in command:
        talk('Openning Chrome')
        target1 = 'C:\\Users\\Public\\Desktop\\Google Chrome.lnk'
        os.startfile(target1)

    elif 'canva'  in command:
        talk('Openning canva')
        target1 = 'C:\\Users\\91916\\Desktop\\Canva.lnk'
        os.startfile(target1) 

    elif 'discord' in command:
        talk('openning discord')
        target1='C:\\Users\\91916\\Desktop\\Discord.lnk'
        os.startfile(target1) 

    elif 'you know veer vijay' in command:
        talk('Yes, I likes Veervijay very much')

    elif 'your date of birth' in command:
        talk('1 april 2001 is my date of birth, now i am 18+')

    elif 'thankyou' in command:
        talk('Your most welcome, You can also thanks to vijay, He created me')

    elif 'heartbeat' in command:
        talk('I love you vijay, Please marry me')

    elif 'like me' in command:
        talk('yes, You are a very good person')

    elif 'kids mode' or 'kids space' in command:
        kids_mode()

    elif 'hear me' in command:
        talk('Yes, I am hearing you')

    elif 'stop listening' in command:
        talk('Ok, Nice to talk you.')
        exit()
    elif 'day' in command:
        tellDay()

    else:
        talk('Please say the command again')



def tellDay():
     
    # This function is for telling the
    # day of the week
    day = datetime.datetime.today().weekday() + 1
     
    #this line tells us about the number
    # that will help us in telling the day
    Day_dict = {1: 'Monday', 2: 'Tuesday',
                3: 'Wednesday', 4: 'Thursday',
                5: 'Friday', 6: 'Saturday',
                7: 'Sunday'}
     
    if day in Day_dict.keys():
        day_of_the_week = Day_dict[day]
        print(day_of_the_week)
        talk("The day is " + day_of_the_week)
         



talk('Hello, I am shashi, your virtual assistance,What can i do for you?')
while True:
    run_shashi()

